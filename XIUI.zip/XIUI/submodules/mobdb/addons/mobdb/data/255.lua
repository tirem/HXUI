--Zone: Abyssea - Empyreal Paradox
--Zone ID: 255
return {
    Names = {
        ['Shinryu'] = { Name='Shinryu', Notorious=true, Aggro=true, Link=false, TrueSight=true, Job=0, MinLevel=90, MaxLevel=92, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={2168,646,17306,1124,902,654,679,796,808,821,2475,4136,4137,4756,4761,4890,5006,5056,5085,5090,5466,11362,11363,11625,11798,15959,16259,18551,19132,745,746,1465,1592,5568,1616,5667,805,792}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=0.5, Ice=1, Wind=0.875, Earth=1, Lightning=1, Water=1, Light=1.25, Dark=0.375} },
    },
    Indices = {
    },
};