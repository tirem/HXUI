--Zone: Outer Ra'Kaznar [U1]
--Zone ID: 275
return {
    Names = {
    },
    Indices = {
    },
};