--Zone: Ruhotz Silvermines
--Zone ID: 93
return {
    Names = {
        ['Sapphire Quadav'] = { Name='Sapphire Quadav', Notorious=false, Aggro=true, Link=true, TrueSight=false, Job=3, MinLevel=60, MaxLevel=60, Immunities=0, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={45,50,53,55,57}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1.125, Wind=1, Earth=1, Lightning=1.25, Water=0.875, Light=1, Dark=1} },
        ['Sapphirine Quadav'] = { Name='Sapphirine Quadav', Notorious=false, Aggro=true, Link=true, TrueSight=false, Job=3, MinLevel=60, MaxLevel=60, Immunities=0, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={45,50,53,55,57}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1.125, Wind=1, Earth=1, Lightning=1.25, Water=0.875, Light=1, Dark=1} },
    },
    Indices = {
    },
};